<?php

namespace App\Http\Controllers;

use App\Models\BloodTransfer;
use Illuminate\Http\Request;

class BloodTransferController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Models\BloodTransfer  $bloodTransfer
     * @return \Illuminate\Http\Response
     */
    public function show(BloodTransfer $bloodTransfer)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Models\BloodTransfer  $bloodTransfer
     * @return \Illuminate\Http\Response
     */
    public function edit(BloodTransfer $bloodTransfer)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Models\BloodTransfer  $bloodTransfer
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, BloodTransfer $bloodTransfer)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\BloodTransfer  $bloodTransfer
     * @return \Illuminate\Http\Response
     */
    public function destroy(BloodTransfer $bloodTransfer)
    {
        //
    }
}
