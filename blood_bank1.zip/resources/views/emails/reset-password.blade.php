<h2>Welcome our customer </h2>
<h4>Click the following link to reset your password:</h4>
<a href="{{ $resetLink }}">{{ $resetLink }}</a>
