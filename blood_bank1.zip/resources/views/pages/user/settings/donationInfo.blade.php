@extends('pages.user.settings')

@section('data')
    <div>
        بالتبرع {{ $user->Username }}قام
    </div>
@endsection
