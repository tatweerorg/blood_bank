@extends('layouts.dashboard-template-user')
@section('content')
    تقارير 
@endsection