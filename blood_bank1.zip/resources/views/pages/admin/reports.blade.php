@extends('layouts.dashboard-template')
@section('content')
    تقارير 
@endsection