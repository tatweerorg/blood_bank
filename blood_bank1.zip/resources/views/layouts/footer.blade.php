 @section('styles')
 <link rel="stylesheet" href="{{ asset('css/footer.css') }}">
 @endsection

 <footer class="footer">
     <div class="container">
         <p>© {{ date('Y') }} جميع الحقوق محفوظة - إدارة بنك الدم</p>
     </div>
 </footer>