
<?php $__env->startSection('content'); ?>
    تقارير 
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.dashboard-template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laravel\blood_bank1\resources\views/pages/admin/reports.blade.php ENDPATH**/ ?>