
<?php $__env->startSection('content'); ?>
<div class="container w-75">

    <!-- Display the heading based on the UserType -->
    <?php if($user->UserType === 'User'): ?>
        <h2 class="w-100 text-end pt-4">الخطوة 2: أدخل فصيلة دمك</h2>
    <?php elseif($user->UserType === 'BloodCenter'): ?>
        <h2 class="w-100 text-end pt-4">الخطوة 2: أدخل العنوان</h2>
    <?php endif; ?>

    <!-- Display success and error messages -->
    <?php if(session('success')): ?>
        <p style="color: green;"><?php echo e(session('success')); ?></p>
    <?php endif; ?>
    <?php if(session('error')): ?>
        <p style="color:red"><?php echo e(session('error')); ?></p>
    <?php endif; ?>
    <!-- Form starts here -->
    <form action="<?php echo e(route('profile.post.step2', ['user_id' => $user_id])); ?>" method="POST">
    <?php echo csrf_field(); ?>
    <?php if($errors->any()): ?>
    <ul>
        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <li>
<?php echo e($error); ?>

        </li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>
    <?php endif; ?>
        <!-- Form for 'User' type -->
        <?php if($user->UserType === 'User'): ?>
        <div class="form-group">
            <label for="BloodType">فصيلة الدم</label>
            <select name="BloodType" id="BloodType" class="form-control">
                <option value="">اختر فصيلة دمك</option>
                <option value="A+" <?php echo e(old('BloodType') == 'A+' ? 'selected' : ''); ?>>A+</option>
                <option value="A-" <?php echo e(old('BloodType') == 'A-' ? 'selected' : ''); ?>>A-</option>
                <option value="B+" <?php echo e(old('BloodType') == 'B+' ? 'selected' : ''); ?>>B+</option>
                <option value="B-" <?php echo e(old('BloodType') == 'B-' ? 'selected' : ''); ?>>B-</option>
                <option value="AB+" <?php echo e(old('BloodType') == 'AB+' ? 'selected' : ''); ?>>AB+</option>
                <option value="AB-" <?php echo e(old('BloodType') == 'AB-' ? 'selected' : ''); ?>>AB-</option>
                <option value="O+" <?php echo e(old('BloodType') == 'O+' ? 'selected' : ''); ?>>O+</option>
                <option value="O-" <?php echo e(old('BloodType') == 'O-' ? 'selected' : ''); ?>>O-</option>
            </select>
            <?php $__errorArgs = ['BloodType'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div class="error" style="color:red;"><?php echo e($message); ?></div>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
        <?php endif; ?>

        <!-- Form for 'BloodCenter' type -->
        <?php if($user->UserType === 'BloodCenter'): ?>
        <div class="form-group">
            <label for="Address">العنوان</label>
            <input type="text" name="Address" id="Address" class="form-control" value="<?php echo e(old('Address')); ?>">
            <?php $__errorArgs = ['Address'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div class="error" style="color:red;"><?php echo e($message); ?></div>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
        <div class="form-group">
            <label for="ContactNumber">رقم الهاتف</label>
            <input type="text" name="ContactNumber" id="ContactNumber" class="form-control" value="<?php echo e(old('ContactNumber')); ?>">
            <?php $__errorArgs = ['ContactNumber'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div class="error" style="color:red;"><?php echo e($message); ?></div>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
       

        <?php endif; ?> 

        <!-- Submit Button -->
        <button type="submit" class="btn btn-danger w-25 m-auto">التالي</button>
    </form>

</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laravel\blood_bank1\resources\views/pages/profile/step2.blade.php ENDPATH**/ ?>