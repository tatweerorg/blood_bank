
<?php $__env->startSection('styles'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('css/hero.css')); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="container">
        <h2>نتائج البحث</h2>
        <?php if(session('error')): ?>
            <div class="alert alert-danger"><?php echo e(session('error')); ?></div>
        <?php endif; ?>

        <?php if($users->isNotEmpty()): ?>
    
            <table class="table table-bordered">
                <thead>
                    <tr>
                        <th>اسم المركز</th>
                        <th>العنوان</th>
                        <th>رقم الاتصال</th>
                        <th>فصيلة الدم</th>
                       
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($user->Username); ?></td>
                            <td><?php echo e($user->profile->Address); ?></td>
                            <td><?php echo e($user->profile->ContactNumber); ?></td>
                            <td><?php echo e($user->profile->BloodType); ?></td>
                          
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
            <?php else: ?>
           <p>لا يوجد مستخدمين بنفس فصيلة الدم هذه</p>
        <?php endif; ?>
    </div>




<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laravel\blood_bank1\resources\views/users.blade.php ENDPATH**/ ?>