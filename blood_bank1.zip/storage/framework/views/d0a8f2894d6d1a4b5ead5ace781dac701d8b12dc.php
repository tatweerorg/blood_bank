

<?php $__env->startSection('data'); ?>
    <div>
        بالتبرع <?php echo e($user->Username); ?>قام
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('pages.user.settings', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laravel\blood_bank1\resources\views/pages/user/settings/donationInfo.blade.php ENDPATH**/ ?>