 <?php $__env->startSection('styles'); ?>
 <link rel="stylesheet" href="<?php echo e(asset('css/footer.css')); ?>">
 <?php $__env->stopSection(); ?>

 <footer class="footer">
     <div class="container">
         <p>© <?php echo e(date('Y')); ?> جميع الحقوق محفوظة - إدارة بنك الدم</p>
     </div>
 </footer><?php /**PATH D:\laravel\blood_bank1\resources\views/layouts/footer.blade.php ENDPATH**/ ?>