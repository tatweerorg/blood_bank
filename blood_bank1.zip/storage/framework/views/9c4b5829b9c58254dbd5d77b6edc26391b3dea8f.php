
<?php $__env->startSection('content'); ?>
    <section class="recent-requests">
        <h2 class="title">المتبرعين</h2>
<div class="containerdelete">
        <a href=""  class="btn btn-danger deletedangerbtn ">إضافة متبرع</a></div>
        <table id="centersTable" class="display">
            <thead>
                <tr>
                    <th>المتبرع</th>
                    <th>مركز التبرع</th>
                    <th>نوع الدم</th>
                    <th>كمية الدم</th>
                    <th>تاريخ التبرع </th>
                    <th>العمليات</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $donations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $donation): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($donation->donor_name); ?></td>
                        <td><?php echo e($donation->center_name); ?></td>
                        <td><?php echo e($donation->blood_type); ?></td>
                        <td><?php echo e($donation->quantity); ?></td>
                        <td><?php echo e($donation->last_donation_date); ?></td>
                        <td>
                            <a href="" class="btn btn-warning editbtn">معلوات</a>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </section>
    <script>
        $(document).ready(function() {
            $('#centersTable').DataTable({
                "language": {
                    "url": "//cdn.datatables.net/plug-ins/1.11.5/i18n/ar.json"
                },
                dom: 'Bfrtip',
                buttons: [

                    {
                        extend: 'print',
                        text: 'طباعة',
                        className: 'btn-print'

                    }
                ]
            });
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('pages.bloodBank.dashbord', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laravel\blood_bank1\resources\views/pages/bloodBank/donors.blade.php ENDPATH**/ ?>