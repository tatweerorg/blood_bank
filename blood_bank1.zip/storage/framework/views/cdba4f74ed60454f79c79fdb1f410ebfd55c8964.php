
<?php $__env->startSection('content'); ?>
    <style>
        .ul {
            display: flex;
            list-style-type: none;
            padding: 0;
            margin: 0;
            width: 100%;
            margin: auto;
            background-color: #d0d0d0;
            border-radius: 10px;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
            overflow: hidden;
        }

        .ul .li {
            border-bottom: 1px solid #ddd;
            width: 35%;
            text-align: center
        }

        .ul .li .a {
            display: block;
            text-decoration: none;
            color: #333;
            font-size: 16px;
            padding: 15px;
            transition: all 0.3s ease;
        }

        .ul .li .a:hover {
            background-color: #007bff;
            color: #fff;
            transform: scale(1.02);
        }

        .ul .li:last-child {
            border-bottom: none;
        }
    </style>
    <ul class="ul">
        <li class="li"><a class="a" href="<?php echo e(route('settings.personalInfo')); ?>">البيانات الشخصية</a></li>
        <li class="li"><a class="a" href="<?php echo e(route('settings.status')); ?>">الحالة المرضية </a></li>
        <li class="li"><a class="a" href="<?php echo e(route('settings.donationInfo')); ?>">سجل التبرعات </a></li>

    </ul>
    <main class="content-area">
        <div id="dynamic-content">
            <?php echo $__env->yieldContent('data'); ?>
        </div>
    </main>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dashboard-template-user', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laravel\blood_bank1\resources\views/pages/user/settings.blade.php ENDPATH**/ ?>