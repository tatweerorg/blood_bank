

<?php $__env->startSection('content'); ?>
    <style>
        .form {}
    </style>
    <form action="<?php echo e(route('dashboarduser.requestsBlood.store')); ?>" method="POST" class="form p-4 bg-light rounded shadow-sm">
        <?php echo csrf_field(); ?>

        <h3 class="text-center mb-4">طلب وحدة دم</h3>

        <div class="form-group mb-3">
            <label for="BloodType" class="form-label">فصيلة الدم</label>


            <select name="BloodType" id="BloodType" class="form-control">
                <option value="">اختر فصيلة دمك</option>
                <option value="A+" <?php echo e(old('BloodType') == 'A+' ? 'selected' : ''); ?>>A+</option>
                <option value="A-" <?php echo e(old('BloodType') == 'A-' ? 'selected' : ''); ?>>A-</option>
                <option value="B+" <?php echo e(old('BloodType') == 'B+' ? 'selected' : ''); ?>>B+</option>
                <option value="B-" <?php echo e(old('BloodType') == 'B-' ? 'selected' : ''); ?>>B-</option>
                <option value="AB+" <?php echo e(old('BloodType') == 'AB+' ? 'selected' : ''); ?>>AB+</option>
                <option value="AB-" <?php echo e(old('BloodType') == 'AB-' ? 'selected' : ''); ?>>AB-</option>
                <option value="O+" <?php echo e(old('BloodType') == 'O+' ? 'selected' : ''); ?>>O+</option>
                <option value="O-" <?php echo e(old('BloodType') == 'O-' ? 'selected' : ''); ?>>O-</option>
            </select>
        </div>

        <div class="form-group mb-3">
            <label for="Quantity" class="form-label">الكمية</label>
            <input type="number" class="form-control" id="Quantity" name="Quantity" required min="1"
                placeholder="Units required">
        </div>

        <div class="form-group mb-3">
            <label for="RequestDate" class="form-label">تاريخ الطلب</label>
            <input type="datetime-local" class="form-control" id="RequestDate" name="RequestDate" required>
            </div>
        <div class="form-group mb-3">
            <label for="center_id" class="form-label">اختيار مركز الدم</label>
            <select class="form-control" id="center_id" name="center_id" required>
                <option value="">اختر مركز الدم</option>
                <option value="all">جميع المراكز</option>
                <?php $__currentLoopData = $bloodCenters; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $center): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($center->id); ?>"><?php echo e($center->Username); ?> </option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>
        <div class="d-grid">
            <button type="submit" class="btn btn-danger">إرسال الطلب</button>
        </div>
    </form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dashboard-template-user', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laravel\blood_bank1\resources\views/pages/user/requestDonation.blade.php ENDPATH**/ ?>