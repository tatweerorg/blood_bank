
<?php $__env->startSection('styles'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('css/hero.css')); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="container">
        <h2>نتائج البحث</h2>

        <?php if(session('error')): ?>
            <div class="alert alert-danger"><?php echo e(session('error')); ?></div>
        <?php endif; ?>

        <?php if($results->isNotEmpty()): ?>
            <table class="table table-bordered">
                <thead>
                    <tr>
                        <th>اسم المركز</th>
                        <th>العنوان</th>
                        <th>رقم الاتصال</th>
                        <th>فصيلة الدم</th>
                        <th>الوحدات المتوفرة</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $results; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $result): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($result->center->Username); ?></td>
                            <td><?php echo e($result->center->profile->Address); ?></td>
                            <td><?php echo e($result->center->profile->ContactNumber); ?></td>
                            <td><?php echo e($result->BloodType); ?></td>
                            <td><?php echo e($result->Quantity); ?></td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        <?php else: ?>
            <p>لا توجد نتائج مطابقة للبحث.</p>
        <?php endif; ?>
    </div>




<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laravel\blood_bank1\resources\views/results.blade.php ENDPATH**/ ?>