<header class="header">
    <div class="container">
        <h1 class="headertitle">
            نظام إدارة بنك الدم


            <i class="fas fa-tint"></i> <!-- Font Awesome blood icon -->
        </h1>
        <nav class="navbar">
            <a href="/">الرئيسية</a>
            <a href="<?php echo e(route('views.about')); ?>">عن النظام</a>
            <a href="#">تواصل معنا</a>
            <a href="<?php echo e(route('login')); ?>">تسجيل دخول</a>
            <a href="<?php echo e(route('dashboard')); ?>"> dashboard</a>


        </nav>
    </div>
</header><?php /**PATH D:\laravel\blood_bank\resources\views/layouts/header.blade.php ENDPATH**/ ?>