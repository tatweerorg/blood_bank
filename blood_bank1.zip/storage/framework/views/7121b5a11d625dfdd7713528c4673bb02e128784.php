
<?php $__env->startSection('styles'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('css/forms.css')); ?>">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <form action="<?php echo e(route('dashboardblood.addBlood')); ?>" method="POST" class="form p-4 bg-light rounded shadow-sm">
        <?php echo csrf_field(); ?>

        <h3 class="text-center mb-4">التبرع بالدم</h3>

        <div class="input-group">
            <label for="BloodType">فصيلة الدم</label>
            <select name="BloodType" id="BloodType" class="input">
                <option value="">اختر فصيلة دمك</option>
                <option value="A+" <?php echo e(old('BloodType') == 'A+' ? 'selected' : ''); ?>>A+</option>
                <option value="A-" <?php echo e(old('BloodType') == 'A-' ? 'selected' : ''); ?>>A-</option>
                <option value="B+" <?php echo e(old('BloodType') == 'B+' ? 'selected' : ''); ?>>B+</option>
                <option value="B-" <?php echo e(old('BloodType') == 'B-' ? 'selected' : ''); ?>>B-</option>
                <option value="AB+" <?php echo e(old('BloodType') == 'AB+' ? 'selected' : ''); ?>>AB+</option>
                <option value="AB-" <?php echo e(old('BloodType') == 'AB-' ? 'selected' : ''); ?>>AB-</option>
                <option value="O+" <?php echo e(old('BloodType') == 'O+' ? 'selected' : ''); ?>>O+</option>
                <option value="O-" <?php echo e(old('BloodType') == 'O-' ? 'selected' : ''); ?>>O-</option>
            </select>
        </div>

        <div class="input-group">
            <label for="Quantity" class="form-label">الكمية</label>
            <input type="number" class="input" id="Quantity" name="Quantity" required min="1"
                placeholder="Units required">
        </div>


        <div class="">
            <button type="submit" class="btn submit">إرسال الطلب</button>
        </div>
    </form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('pages.bloodBank.dashbord', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laravel\blood_bank1\resources\views/pages/bloodBank/donate.blade.php ENDPATH**/ ?>