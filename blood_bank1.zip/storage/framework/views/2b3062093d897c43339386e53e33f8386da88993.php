<header class="header">
    <div class="container">
        <h1 class="headertitle">
            <img src="<?php echo e(asset('images/logo.png')); ?>" alt="logo">
            <span>دَمُك حياة</span>
        </h1>
        <nav class="navbar">
            <a href="/">الرئيسية</a>
            <a href="<?php echo e(route('views.about')); ?>">عن النظام</a>
            <a href="<?php echo e(route('views.contact')); ?>">تواصل معنا</a>
            <a href="<?php echo e(route('login')); ?>" class="loginmobile">تسجيل دخول</a>
            <a href="<?php echo e(route('roles')); ?>" class="loginmobile">إنشاء حساب</a>
            <div class="login">
                <a href="<?php echo e(route('login')); ?>">تسجيل دخول</a>
                <a href="<?php echo e(route('roles')); ?>">إنشاء حساب</a>
            </div>
        </nav>

    </div>
</header><?php /**PATH D:\laravel\blood_bank1\resources\views/layouts/header.blade.php ENDPATH**/ ?>