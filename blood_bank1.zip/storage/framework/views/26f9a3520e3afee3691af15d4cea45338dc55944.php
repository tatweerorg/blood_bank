
<?php $__env->startSection('styles'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('css/hero.css')); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <section class="container">

        <div class="container my-5">
            <?php if(session('error')): ?>
                <div class="alert alert-danger ">
                    <?php echo e(session('error')); ?>



                </div>
            <?php endif; ?>

            <h2>أدخل تفاصيل الطلب</h2>
            <p>املأ الحقول أدناه لمعرفة المراكز التي تتوفر فيها الدم المطلوب</p>
            <form action="<?php echo e(route('search')); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <div class="form-group">
                    <label for="BloodType">فصيلة الدم</label>
                    <select name="BloodType" id="BloodType" class="form-control">
                        <option value="">اختر فصيلة دمك</option>
                        <option value="A+" <?php echo e(old('BloodType') == 'A+' ? 'selected' : ''); ?>>A+</option>
                        <option value="A-" <?php echo e(old('BloodType') == 'A-' ? 'selected' : ''); ?>>A-</option>
                        <option value="B+" <?php echo e(old('BloodType') == 'B+' ? 'selected' : ''); ?>>B+</option>
                        <option value="B-" <?php echo e(old('BloodType') == 'B-' ? 'selected' : ''); ?>>B-</option>
                        <option value="AB+" <?php echo e(old('BloodType') == 'AB+' ? 'selected' : ''); ?>>AB+</option>
                        <option value="AB-" <?php echo e(old('BloodType') == 'AB-' ? 'selected' : ''); ?>>AB-</option>
                        <option value="O+" <?php echo e(old('BloodType') == 'O+' ? 'selected' : ''); ?>>O+</option>
                        <option value="O-" <?php echo e(old('BloodType') == 'O-' ? 'selected' : ''); ?>>O-</option>
                    </select>
                </div>

                <!-- Units input -->
                <div class="form-group">
                    <label for="units">عدد الوحدات المطلوبة</label>
                    <input type="number" name="units" id="units" class="form-control" placeholder="عدد الوحدات"
                        min="1" required>
                </div>

                <!-- Location input -->
                <div class="form-group mb-3">
                    <label for="location">المكان</label>
                    <input type="text" name="location" id="location" class="form-control"
                        placeholder="المدينة أو المنطقة" required>
                </div>
                <button type="submit" class="btn btn-primary search-btn">ابحث الآن</button>

            </form>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laravel\blood_bank1\resources\views/requests.blade.php ENDPATH**/ ?>