

<?php $__env->startSection('content'); ?>
    <div class="container w-75 py-5">
        <h2 class="text-end py-4 text-danger">إكمال الملف الشخصي</h2>

        <div class="card shadow border-0">
            <div class="card-body">
                <form action="<?php echo e(route('profile.complete', ['user_id' => $user_id])); ?>" method="POST"
                    enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>

                    <!-- صورة الملف الشخصي -->
                    <div class="form-group mb-4">
                        <label for="profile_image" class="w-100 text-end fw-bold">صورة الملف الشخصي</label>
                        <input type="file" id="profile_image" name="profile_image" class="form-control">
                        <?php $__errorArgs = ['profile_image'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="text-danger small"><?php echo e($message); ?></div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    <!-- فصيلة الدم أو العنوان -->
                    <?php if($user->UserType === 'User'): ?>
                        <div class="form-group mb-4">
                            <label for="BloodType" class="w-100 text-end fw-bold">فصيلة الدم</label>
                            <select name="BloodType" id="BloodType" class="form-select">
                                <option value="">اختر فصيلة دمك</option>
                                <option value="A+" <?php echo e(old('BloodType') == 'A+' ? 'selected' : ''); ?>>A+</option>
                                <option value="A-" <?php echo e(old('BloodType') == 'A-' ? 'selected' : ''); ?>>A-</option>
                                <option value="B+" <?php echo e(old('BloodType') == 'B+' ? 'selected' : ''); ?>>B+</option>
                                <option value="B-" <?php echo e(old('BloodType') == 'B-' ? 'selected' : ''); ?>>B-</option>
                                <option value="AB+" <?php echo e(old('BloodType') == 'AB+' ? 'selected' : ''); ?>>AB+</option>
                                <option value="AB-" <?php echo e(old('BloodType') == 'AB-' ? 'selected' : ''); ?>>AB-</option>
                                <option value="O+" <?php echo e(old('BloodType') == 'O+' ? 'selected' : ''); ?>>O+</option>
                                <option value="O-" <?php echo e(old('BloodType') == 'O-' ? 'selected' : ''); ?>>O-</option>
                            </select>
                            <?php $__errorArgs = ['BloodType'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="text-danger small"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    <?php elseif($user->UserType === 'BloodCenter'): ?>
                        <div class="form-group mb-4">
                            <label for="Address" class="w-100 text-end fw-bold">العنوان</label>
                            <input type="text" name="Address" id="Address" class="form-control"
                                value="<?php echo e(old('Address')); ?>">
                            <?php $__errorArgs = ['Address'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="text-danger small"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                        <div class="form-group mb-4">
                            <label for="ContactNumber" class="w-100 text-end fw-bold">رقم الهاتف</label>
                            <input type="text" name="ContactNumber" id="ContactNumber" class="form-control"
                                value="<?php echo e(old('ContactNumber')); ?>">
                            <?php $__errorArgs = ['ContactNumber'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="text-danger small"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    <?php endif; ?>

                    <!-- تاريخ الميلاد -->
                    <?php if($user->UserType === 'User'): ?>
                        <div class="form-group mb-4">
                            <label for="DateOfBirth" class="w-100 text-end fw-bold">تاريخ الميلاد</label>
                            <input type="date" name="DateOfBirth" id="DateOfBirth" class="form-control"
                                value="<?php echo e(old('DateOfBirth')); ?>">
                            <?php $__errorArgs = ['DateOfBirth'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="text-danger small"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <!-- عنوان المستخدم -->
                        <div class="form-group mb-4">
                            <label for="Address" class="w-100 text-end fw-bold">العنوان</label>
                            <textarea name="Address" id="Address" class="form-control <?php $__errorArgs = ['Address'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" required><?php echo e(old('Address')); ?></textarea>
                            <?php $__errorArgs = ['Address'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="text-danger small"><?php echo e($message); ?></span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                        <!-- رقم الهاتف -->
                        <div class="form-group mb-4">
                            <label for="ContactNumber" class="w-100 text-end fw-bold">رقم الهاتف</label>
                            <input type="text" name="ContactNumber" id="ContactNumber"
                                class="form-control <?php $__errorArgs = ['ContactNumber'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" required
                                value="<?php echo e(old('ContactNumber')); ?>">
                            <?php $__errorArgs = ['ContactNumber'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="text-danger small"><?php echo e($message); ?></span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    <?php endif; ?>


                    <!-- زر الإرسال -->
                    <div class="text-center mt-4">
                        <button type="submit" class="btn btn-danger w-50">إكمال</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laravel\blood_bank1\resources\views/pages/profile/completeProfileView.blade.php ENDPATH**/ ?>