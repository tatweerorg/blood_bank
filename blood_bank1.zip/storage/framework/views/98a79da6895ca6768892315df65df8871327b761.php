


<?php $__env->startSection('content'); ?>
    <section class="">
        <div class="card-info">



            <div class="user-info">

                <img class="profileImage" src="<?php echo e(asset('storage/' . $userProfile->profile_image)); ?>" alt="profile img">

                <h1 class="fs-2">اهلاً بعودتك <?php echo e($user->Username); ?></h1>
            </div>
            <div>
                <p><?php echo e($donationcount); ?></p>
                <p>تبرعاتك</p>
            </div>

            <div>
                <p><?php echo e($bloodbankscount); ?></p>
                <p>بنوك الدم</p>

            </div>
            <div>
                <p><?php echo e($pendingrequests); ?></p>
                <p>طلبات التبرع المعلقة</p>

            </div>

        </div>
        <div class="notification">
            <div class="notifi-header">
                <p class="fs-4">جميع الاشعارات </p>
                <span><?php echo e($remindercount); ?></span>
            </div>
            <div class="body">
                <div>
                    <?php if($remindercount > 0): ?>
                    <?php $__currentLoopData = $reminders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $reminder): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <h1>من <?php echo e($reminder->sender_name); ?> </h1>
                    <?php if($reminder->reminder === 'approve'): ?>
                    تم قبول الطلب المقدم من قبل <?php echo e($reminder->sender_name); ?> 
                    <?php elseif($reminder->reminder === 'cancelled'): ?>
                    تم رفض الطلب المقدم من قبل <?php echo e($reminder->sender_name); ?> 
                    <?php elseif($reminder->reminder === 'donate'): ?>
                    تم حجز موعد التبرع بالدم من قبل <?php echo e($reminder->sender_name); ?>في تاريخ <?php echo e($reminder->reminder_date); ?>

                    <?php elseif($reminder->reminder === 'request'): ?>
                    تم طلب دم من قبل <?php echo e($reminder->sender_name); ?>في تاريخ <?php echo e($reminder->reminder_date); ?>


                    <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>     
                    <?php elseif($remindercount==0): ?> 
                    لا يوجد إشعارات
                    <?php endif; ?>        
                </div>

            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dashboard-template-user', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laravel\blood_bank1\resources\views/pages/user/dashboard.blade.php ENDPATH**/ ?>