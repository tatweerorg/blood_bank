
<?php $__env->startSection('content'); ?>
    <form action="<?php echo e(route('dashboarduser.giveBlood.store')); ?>" method="POST" class="form p-4 bg-light rounded shadow-sm">
        <?php echo csrf_field(); ?>

        <h3 class="text-center mb-4">التبرع بالدم</h3>

        <div class="form-group mb-3">
            <label for="blood_type" class="form-label">فصيلة الدم</label>



            <select name="blood_type" id="blood_type" class="form-control">
                <option value="">اختر فصيلة دمك</option>
                <option value="A+" <?php echo e(old('BloodType') == 'A+' ? 'selected' : ''); ?>>A+</option>
                <option value="A-" <?php echo e(old('BloodType') == 'A-' ? 'selected' : ''); ?>>A-</option>
                <option value="B+" <?php echo e(old('BloodType') == 'B+' ? 'selected' : ''); ?>>B+</option>
                <option value="B-" <?php echo e(old('BloodType') == 'B-' ? 'selected' : ''); ?>>B-</option>
                <option value="AB+" <?php echo e(old('BloodType') == 'AB+' ? 'selected' : ''); ?>>AB+</option>
                <option value="AB-" <?php echo e(old('BloodType') == 'AB-' ? 'selected' : ''); ?>>AB-</option>
                <option value="O+" <?php echo e(old('BloodType') == 'O+' ? 'selected' : ''); ?>>O+</option>
                <option value="O-" <?php echo e(old('BloodType') == 'O-' ? 'selected' : ''); ?>>O-</option>
            </select>
        </div>

        <div class="form-group mb-3">
            <label for="quantity" class="form-label">الكمية</label>
            <input type="number" class="form-control" id="quantity" name="quantity" required min="1"
                placeholder="Units required">
        </div>

        <div class="form-group mb-3">
            <label for="last_donation_date" class="form-label">التاريخ المتاح </label>
            <input type="datetime-local" class="form-control" id="last_donation_date" name="last_donation_date" required>
        </div>

        <div class="form-group mb-3">
            <label for="center_id" class="form-label">اختر مركز التبرع</label>
            <select name="center_id" id="center_id" class="form-control" required>
                <option value="" disabled selected>اختر مركز</option>
                <?php $__currentLoopData = $centers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $center): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($center->id); ?>"><?php echo e($center->Username); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>

        <div class="d-grid">
            <button type="submit" class="btn btn-danger">إرسال الطلب</button>
        </div>
    </form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dashboard-template-user', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laravel\blood_bank1\resources\views/pages/user/giveDonation.blade.php ENDPATH**/ ?>