
<?php $__env->startSection('content'); ?>
    <section class="dashboard-cards">
        <div class="card">
            <h3>إجمالي التبرعات</h3>
            <p><?php echo e($donationcount); ?></p>
        </div>
        <div class="card">
            <h3>وحدات الدم المتاحة</h3>
            <p><?php echo e($quantity); ?></p>
        </div>
        <div class="card">
            <h3>الطلبات المعلقة</h3>
            <p><?php echo e($pendingrequests); ?></p>
        </div>
        <div class="card">
            <h3>إجمالي المتبرعين</h3>
            <p><?php echo e($donorcount); ?></p>
        </div>
    </section>
    <section class="recent-requests">
        <h2>طلبات التبرع الأخيرة</h2>
        <table>
            <thead>
                <tr>
                    <th>اسم المتبرع</th>
                    <th>فصيلة الدم</th>
                    <th>التاريخ</th>
                    <th>الحالة</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $bloodrequests; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $request): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($request->Username); ?> </td>
                        <td><?php echo e($request->BloodType); ?></td>
                        <td><?php echo e($request->RequestDate); ?></td>
                        <td
                            style="
    <?php if($request->Status == 'Approved'): ?> background-color: green; color: white; 
    <?php elseif($request->Status == 'Pending'): ?> 
        background-color: yellow; color: black; 
    <?php else: ?> 
        background-color: orange; color: white; <?php endif; ?>">
                            <?php if($request->Status == 'Approved'): ?>
                                موافقة
                            <?php elseif($request->Status == 'Pending'): ?>
                                انتظار
                            <?php else: ?>
                                مرفوضة
                            <?php endif; ?>
                        </td> 
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            </tbody>
        </table>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dashboard-template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laravel\blood_bank1\resources\views/pages/admin/main.blade.php ENDPATH**/ ?>