

<?php $__env->startSection('data'); ?>
    <form action="<?php echo e(route('settings.updatepersonalinfo')); ?>" method="POST" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
        <div>
            <label for="disease">disease:</label>
            <input type="text" id="disease" name="disease">

        </div>
        <button>Add disease</button>
    </form>
    <div>
        <h2> All diseases</h2>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('pages.user.settings', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laravel\blood_bank1\resources\views/pages/user/settings/status.blade.php ENDPATH**/ ?>