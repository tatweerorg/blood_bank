
<?php $__env->startSection('content'); ?>
<section class="recent-requests">
    <h2 class="title">مخزون الدم </h2>
    <table id="centersTable" class="display">
        <thead>
            <tr>
                <th>مركز الدم</th>
                <th>نوع فصيلة الدم </th>
                <th>كمية الدم </th>
                <th>تاريخ الانتهاء</th>
                <th>العمليات</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $inventores; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $inventory): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($inventory->Username); ?></td>
                <td><?php echo e($inventory->BloodType); ?></td>
                <td><?php echo e($inventory->Quantity); ?></td>
                <td><?php echo e($inventory->ExpirationDate); ?></td>
                <td>
                <a href="<?php echo e(route('bloodInventory.edit', $inventory->id )); ?>" class="btn btn-warning editbtn">Edit</a>
                <a href="#" class="btn btn-danger deletebtn">Delete</a>
                </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</section>
<script>
    $(document).ready(function(){
        $('#centersTable').DataTable({
            "language": {
                "url": "//cdn.datatables.net/plug-ins/1.11.5/i18n/ar.json" 
            },
            dom: 'Bfrtip',
            buttons: [
               
                {
                    extend: 'print',
                    text: 'طباعة',
                                        className: 'btn-print'

                                        
                }
            ]
        })
    }

    )
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.dashboard-template-user', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laravel\blood_bank1\resources\views/pages/user/bloodInventory.blade.php ENDPATH**/ ?>